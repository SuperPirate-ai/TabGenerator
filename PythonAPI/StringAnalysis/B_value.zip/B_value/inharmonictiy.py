f0  = 110
overtones = [110,220,330,440,550]

#make a list of multiples of f0 starting from f0
multiples_f0 = [f0, f0*2, f0*3, f0*4, f0*5]




